import React, { useState } from "react";

export default function InputBox({ onSend }: { onSend: (text: string) => void }) {
  const [text, setText] = useState("");

  const submit = () => {
    const t = text.trim();
    if (!t) return;
    onSend(t);
    setText("");
  };

  return (
    <div className="flex gap-2">
      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
        className="flex-1 border rounded px-3 py-2"
        placeholder="Напиши сообщение..."
      />
      <button onClick={submit} className="bg-blue-600 text-white px-4 py-2 rounded">Отправить</button>
    </div>
  );
}
