import React, { useRef, useEffect } from "react";
import { Message } from "../App";
import MessageBubble from "./MessageBubble";

export default function ChatWindow({ messages }: { messages: Message[] }) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [messages]);

  return (
    <div ref={ref} className="h-full overflow-y-auto p-2 space-y-3">
      {messages.length === 0 && (
        <div className="text-gray-500">Привет! Напиши что-нибудь, чтобы начать.</div>
      )}
      {messages.map((m) => (
        <MessageBubble key={m.id} message={m} />
      ))}
    </div>
  );
}
