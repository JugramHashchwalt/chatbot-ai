import React from "react";
import { Message } from "../App";

export default function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`${isUser ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-900"} p-3 rounded-lg max-w-[70%]`}>
        {message.text}
      </div>
    </div>
  );
}
