import React, { useState } from "react";
import ChatWindow from "./components/ChatWindow";
import InputBox from "./components/InputBox";

export type Message = {
  id: string;
  role: "user" | "bot";
  text: string;
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);

  const sendMessage = async (text: string) => {
    const userMessage: Message = { id: Date.now().toString(), role: "user", text };
    setMessages((m) => [...m, userMessage]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });
      if (!res.ok) throw new Error("Server error");
      const data = await res.json();
      const botText = data.reply ?? "Нет ответа.";
      const botMessage: Message = { id: (Date.now()+1).toString(), role: "bot", text: botText };
      setMessages((m) => [...m, botMessage]);
    } catch (err) {
      const errMsg: Message = { id: (Date.now()+2).toString(), role: "bot", text: "Ошибка: не удалось связаться с сервером." };
      setMessages((m) => [...m, errMsg]);
      console.error(err);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <header className="p-4 bg-white shadow">
        <h1 className="text-xl font-semibold">ChatBot AI (GPT-4)</h1>
      </header>

      <main className="flex-1 p-4">
        <ChatWindow messages={messages} />
      </main>

      <footer className="p-4 bg-white border-t">
        <InputBox onSend={sendMessage} />
      </footer>
    </div>
  );
}
